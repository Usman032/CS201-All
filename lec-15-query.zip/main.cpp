#include<iostream>
using namespace std;

int main()
{
    int x = 10;
    int *pointer;
    pointer = &x;
    cout<< "Address of x is =  " << pointer<<endl;
    cout<< "Value of x is = "<< *pointer<<endl;
    *pointer --;
    cout<<"*pointer-- is = "<< *pointer --<<endl; // why does it not decrement the 'x'?
    cout<<"*pointer-- is = "<< *pointer --<<endl; 
    cout<<"*pointer++ is = "<< *pointer ++<<endl; // why it does not increment the 'x'?
    cout<<"pointer-- is = "<< pointer --<<endl;  // it decrements the address (pointer).
    cout<<"pointer-- is = "<< pointer --<<endl;    
    cout<<"pointer++ is = "<< pointer ++<<endl;  // it increment the address (pointer).
    return 0;
}