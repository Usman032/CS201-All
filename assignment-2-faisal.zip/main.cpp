#include<iostream>

using namespace std;

/* Definitions of functions 
   Function 1
*/

void showElements(long int data[][5])
{
	cout<<"Source Data:\n\nStates\t\tBiden Votes\tTrump Votes\tJorgensen Votes\tTotal Votes\n\n";
	for(int i=0; i<3; i++)
	{
		for(int j=0; j<5; j++)
		{
			cout<<data[i][j]<<"\t\t";
		}
		cout<<"\n";
	}
}   

//  Function 2
double PercentageBiden(long int data[3][5], int userInput)
{
	double percentage[3]={0.0};
	for(int i=0; i<3; i++)
	{
		percentage[i] = (double ) 100*data[i][1] / data[i][4];
	}
	return percentage[userInput];
}  

//  Function 3
double PercentageTrump(long int data[3][5], int userInput)
{
	double percentage[3]={0.0};
	for(int i=0; i<3; i++)
	{
		percentage[i] = (double ) 100*data[i][2] / data[i][4];
	}
	return percentage[userInput];
}   

//  Function 4
double PercentageJorgensen(long int data[3][5], int userInput)
{
	double percentage[3]={0.0};
	for(int i=0; i<3; i++)
	{
		percentage[i] = (double ) 100*data[i][3] / data[i][4];
	}
	return percentage[userInput];
}   

//  Function 5
void line()
{
    cout<<"\n-------------------------------------------------------------------";
}

//  start of main()
int main()
{
    int userInput=0;
    int loopControl;	
    long int data[3][5]={{ 1, 5284453, 5658847, 70046, 11013346},
                        { 2, 2465781, 2455428, 61894, 4983103},
                        { 3, 2790648, 2644525, 60287, 5495460},};

    showElements(data); // function call.

    //  Take user input.
    do
    {
        cout<<"\nPress the state code to calculate the percentage of Trump, Biden and Jorgensen votes";
        cout<<"\nPress 1 for Florida.\nPress 2 for Georgia.\nPress 3 for Michigan.\nPress 4 to exit";
        cout<<"\nPlease select an userInput, use number from 1 to 4: ";
        cin>>userInput;

        if(userInput == 1)

            /*  Calling functions of candidates vote percentage  */
        {
            line();
            cout<<"\nPercentage of Jo Biden vote is 	: "<<PercentageBiden(data, userInput-1);
            cout<<"\nPercentage of Donald Trump vote is : "<<PercentageTrump(data, userInput-1);
            cout<<"\nPercentage of Jo Jorgensen vote is : "<<PercentageJorgensen(data, userInput-1);
    	}
        else if(userInput == 2)
        {
            line();
            cout<<"\nPercentage of Jo Biden vote is 	: "<<PercentageBiden(data, userInput-1);
            cout<<"\nPercentage of Donald Trump vote is : "<<PercentageTrump(data, userInput-1);
            cout<<"\nPercentage of Jo Jorgensen vote is : "<<PercentageJorgensen(data, userInput-1);
    	}
        else if(userInput == 3)
        {
            line();
            cout<<"\nPercentage of Jo Biden vote is 	: "<<PercentageBiden(data, userInput-1);
            cout<<"\nPercentage of Donald Trump vote is : "<<PercentageTrump(data, userInput-1);
            cout<<"\nPercentage of Jo Jorgensen vote is : "<<PercentageJorgensen(data, userInput-1);
    	}
        else if(userInput == 4)
        {
            cout<<"\n\t********** Thanks **********";
            loopControl = userInput;
    	}     
		else
        {
            cout<<"\nChoice should be between 1 and 4\nInvalid choice, please select again:"<<endl;
            continue;
        }
    }
    while(loopControl != 4);
    return 0;
}  //  end of main()
