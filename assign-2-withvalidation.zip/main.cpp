#include<iostream>
#include <limits>

using namespace std;

void showElements(int sourceData[][5]);  // Function Prototype displaying source sourceData from 2D array.
double PercentageBiden(int sourceData[][5], int);  // Function Prototype for calculating vote %age of Biden.
double PercentageTrump(int sourceData[][5], int);  // Function Prototype for calculating vote %age of D. Trump.
double PercentageJorgensen(int sourceData[][5], int);  // Function Prototype for calculating vote %age of Jorgensen.
void drawLine();  // Prototype for drawing line.
int validateTry(int);

int main()
{
    int option=0;
    int controlVariable;    //  control1
    // variable for while loop
    int sourceData[3][5]={
                        { 1, 5284453, 5658847, 70046, 11013346},
                        { 2, 2465781, 2455428, 61894, 4983103},
                        { 3, 2790648, 2644525, 60287, 5495460},
                   };

    showElements(sourceData); //  Calling showElements() to show source sourceData stored in a 2D array (int sourceData[3][5]).

    //  Take user's options for all candidates votes %age per states .

        do {
            cout << "\nPress the state code to calculate the percentage of Trump, Biden and Jorgensen votes";
            cout << "\nPress 1 for Florida.\nPress 2 for Georgia.\nPress 3 for Michigan.\nPress 4 to exit";
            cout << "\nPlease select an option, use number from 1 to 4: ";
//            while (!(cin>>option)){
//                cout<<"\nNot a valid input, Please use numbers from 1 to 4: ";
//                cin.clear();
//                cin.ignore(100, '\n');
//            }

//            cin >> option;

            if (validateTry(option) == 1)
                /*  Calling functions for showing the candidates' state wise votes %age
                 *  Subtract 1 from user's option to match it with the array's index numbers  */
            {
                drawLine(); // Calling drawLine() function.
                cout << "\nPercentage of Jo Biden vote is 	: " << PercentageBiden(sourceData, option - 1);
                cout << "\nPercentage of Donald Trump vote is : " << PercentageTrump(sourceData, option - 1);
                cout << "\nPercentage of Jo Jorgensen vote is : " << PercentageJorgensen(sourceData, option - 1);
            } else if (validateTry(option) == 2) {
                drawLine();
                cout << "\nPercentage of Jo Biden vote is 	: " << PercentageBiden(sourceData, option - 1);
                cout << "\nPercentage of Donald Trump vote is : " << PercentageTrump(sourceData, option - 1);
                cout << "\nPercentage of Jo Jorgensen vote is : " << PercentageJorgensen(sourceData, option - 1);
            } else if (validateTry(option) == 3) {
                drawLine();
                cout << "\nPercentage of Jo Biden vote is 	: " << PercentageBiden(sourceData, option - 1);
                cout << "\nPercentage of Donald Trump vote is : " << PercentageTrump(sourceData, option - 1);
                cout << "\nPercentage of Jo Jorgensen vote is : " << PercentageJorgensen(sourceData, option - 1);
            } else if (validateTry(option) == 4) {
                cout << "\n\n\t\t******* Thank You *******";
                controlVariable = option;
//                break;      // Do avoid endless loop with while(true)
            } else {
                cout << "\nChoice should be between 1 and 4\nInvalid choice, please select again:" << endl;
                continue;
            }
        } while (controlVariable != 4);   // end of do-while loop.
    return 0;
}   // end of main().

// This function takes a 2D array as argument and displays its contents
void showElements(int sourceData[][5])
{
	cout<<"Source sourceData:\n\nStates\t\tBiden Votes\tTrump Votes\tJorgensen Votes\tTotal Votes\n\n";
	for(int i=0; i<3; i++)
	{
		for(int j=0; j<5; j++)
		{
			cout<<sourceData[i][j]<<"\t\t";
		}
		cout<<"\n";
	}
}   // End of void showElements(int sourceData[][5]).

/* This function takes 2 arguments: An integer value from user and a multidimensional (2D) array
 * and returns Biden's votes percentage in a double sourceDatatype.
 * The user input works integer is the array-index number (1, 2, or 3) as code of the three states*/
 double PercentageBiden(int sourceData[3][5], int option)
{
	double percentage[3]={0.0};
	for(int i=0; i<3; i++)
	{
		percentage[i] = (double ) 100*sourceData[i][1] / sourceData[i][4];
	}
	return percentage[option];
}   // End of  double PercentageBiden(int sourceData[3][5], int option).

/* This function takes 2 arguments: An integer value from user and a multidimensional (2D) array
 * and returns Donald Trump's votes percentage in a double sourceDatatype.
 * The user input works integer is the array-index number (1, 2, or 3) as code of the three states*/
double PercentageTrump(int sourceData[3][5], int option)
{
	double percentage[3]={0.0};
	for(int i=0; i<3; i++)
	{
		percentage[i] = (double ) 100*sourceData[i][2] / sourceData[i][4];
	}
	return percentage[option];
}   // End of double PercentageTrump(int sourceData[3][5], int option).

/* This function takes 2 arguments: An integer value from user and a multidimensional (2D) array
 * and returns Jo Jorgensen votes percentage in a double sourceDatatype.
 * The user input works integer is the array-index number (1, 2, or 3) as code of the three states*/
double PercentageJorgensen(int sourceData[3][5], int option)
{
	double percentage[3]={0.0};
	for(int i=0; i<3; i++)
	{
		percentage[i] = (double ) 100*sourceData[i][3] / sourceData[i][4];
	}
	return percentage[option];
}   // End of double PercentageJorgensen(int sourceData[3][5], int option).

// Drawing line
void drawLine()
{
    cout<<"\n------------------------------------------------------------------";
}


double read_input()
{
    int input = -1;

    bool valid= false;
    do
    {
        cout << "Enter  numbers from 1 to 4: ";
        cin >> input;
        if (cin.good())
        {
            //everything went well, we'll get out of the loop and return the value
            valid = true;
        }
        else
        {
            //something went wrong, we reset the buffer's state to good
            cin.clear();
            //and empty it
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout << "Invalid input; please re-enter." << endl;
        }
    } while (!valid);

    return (input);
}

int validateTry(int){
    int option;
    while (!(cin>>option)){
        cout<<"\nNot a valid input, Please use numbers from 1 to 4: ";
        cin.clear();
        cin.ignore(100, '\n');
    }
    return option;
}
