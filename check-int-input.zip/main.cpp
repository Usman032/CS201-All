#include <iostream>
using namespace std;

int main(){
    int userInput = 'y';
    cout<<userInput<<" please Enter a digit."<<endl;
            cin>>userInput;
    if(cin.fail()){
        cout<<"not a digit! plz a a a a .";
    }
    else{
//        cin>>userInput;
        cout<<"ur r r  r r "<<userInput<<endl;
    }
}