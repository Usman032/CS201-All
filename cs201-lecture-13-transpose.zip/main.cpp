#include <iostream>
using namespace std;

int
main ()
{
  int arraySize = 3;
  int row = 0, col = 0;
  int a[arraySize][arraySize];
  int temp;

// input for sq array a[]
  for (row = 0; row < arraySize; row++)
    {
      for (col = 0; col < arraySize; col++)
	{
	  cout << "Enter the value for [" << row << "] [" << col << "] : ";
	  cin >> a[row][col];
	}
    }

// print sq array a[]
  for (row = 0; row < arraySize; row++)
    {
      for (col = 0; col < arraySize; col++)
	{
	  cout << a[row][col] << '\t';
	}
      cout << "\n";
    }

// transposing
  for (row = 0; row < arraySize; row++)
    {
      for (col = row; col < arraySize; col++)
	{
// Interchange the values here using the swapping mechanism
	  temp = a[row][col];	// Save the original value in the temp variable
	  a[row][col] = a[col][row];
	  a[col][row] = temp;	//Take out the original value
	}
    }

// print array a[] after transposing
    cout<<"\nprint array a[] after transposing\n";
    for (row = 0; row < arraySize; row ++)
        {
            for(col=0; col < arraySize; col ++)
            {
            cout <<a[row][col]<< '\t';
            }
            cout<<"\n";
        }



  return 0;
}
