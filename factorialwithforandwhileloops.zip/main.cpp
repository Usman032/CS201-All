#include<iostream>
using namespace std;


int main()
{
    int n = 1;
    int n2;
    unsigned long long int factorial = 1;

    cout << "Enter a positive integer: ";
    cin >> n;
    
    // covert input to positive if it is negative
    if(n<0){
    //  n= -n;
    //  n = n * -1;
        n *= -1;
    }
    n2 = n;
    
    for(int i = 1; i<=n; i++){
        factorial *= i;
    }
    cout<<"The factorial is of positive "<<n<<" is "<<" = "<<factorial<<endl;

    // while (n>=1)
    //     {
    //         factorial = factorial * n;
    //         n = n-1;
    //     }
    // cout << "Factorial of " << n2 << " = " << factorial;

    return 0;
}

