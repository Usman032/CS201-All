#include <iostream>
using namespace std;

main()
{
	long long number;
	int digit;
	int digit1=0, digit2=0, digit3=0, digit4=0; 
	cout<<"Please enter a 4 digit number "<<'\n';

	cin>>number;
	digit = number % 10;
	cout<<"The digit is: "<<digit<<endl;
	digit1 = digit;
	number = number / 10;
	
	digit = number % 10;
	cout<<"The digit is: "<<digit<<endl;
	digit2 = digit;
	number = number / 10;
	
	digit = number % 10;
	cout<<"The digit is: "<<digit<<endl;
	digit3 = digit;
	number = number / 10;
	
	digit = number % 10;
	cout<<"The digit is: "<<digit<<endl;
	digit4 = digit;
	number = number / 10;

    cout<<"The digits in correct order are:"<<endl;
	cout<<digit4<<endl;
	cout<<digit3<<endl;
	cout<<digit2<<endl;
	cout<<digit1;	
}
