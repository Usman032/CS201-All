#include <iostream>
using namespace std;

main()
{
	long long number;
	long long number2;
	int digit;
	int count = 0;
	int digit1=0, digit2=0, digit3=0, digit4=0; 
	
	cout<<"Please enter a 4 digit number "<<'\n';
	
	cin>>number;
	number2 = number;

    // to find the number of digits in the "entered" number
	while(number!=0){
		number = number /= 10;
		++count; // the number of digits in the "entered" number
	}
	if(count==4){
		for(digit = count; digit>0; digit--){
			
			int remainder = number2 % 10;
			cout<<remainder <<endl;
			number2 = number2 / 10;
			
			if(!digit1 > 0){
				digit1 = remainder;
			}
			else if(!digit2 > 0){
					digit2 = remainder;
			}
			else if(!digit3 > 0){
					digit3 = remainder;
			}
			else if(!digit4 > 0){
					digit4 = remainder;
			}			
		}
		cout<<"The digits in correct order are: "<<'\n';
		cout<<digit4<<'\n'<<digit3<<'\n'<<digit2<<'\n'<<digit1<<'\n';

	}
	else{
		cout<<"Plese enter 4 digits only"<<endl;
	}
		

}
